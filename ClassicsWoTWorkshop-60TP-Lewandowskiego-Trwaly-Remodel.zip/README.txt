Thank you for downloading! To install, drag the included .wotmod files to <Your WoT Directory\mods\<Game Version>

(Example: C:\Games\World_of_Tanks\mods\1.10.0.0)

Made by FastestClassic.